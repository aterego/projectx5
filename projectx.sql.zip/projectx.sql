-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 05:41 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projectx`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
`id` int(11) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_balance`
--

DROP TABLE IF EXISTS `account_balance`;
CREATE TABLE IF NOT EXISTS `account_balance` (
`id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `available` float NOT NULL,
  `blocked` float NOT NULL,
  `last_transaction_id` int(11) NOT NULL,
  `last_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
`id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `avatar` blob,
  `phone` varchar(25) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `name`, `email`, `password`, `roles_id`, `avatar`, `phone`, `created`) VALUES
(1, 'magister', 'Super Admin', 'dr.aranea@gmail.com', '$MYHASH$V1$10000$RQEVDajRI07RNDTPPYHO+40XE7d8LdLEe0vgsHwahjXmzlvH', 1, '', '+995 55507706', '2019-04-14 10:30:32'),
(3, 'admin', 'Adminstrator', 'admin@admin.com', '$MYHASH$V1$10000$guVBob4c2srybIm8XJHMeg/3Lv6g9uum6wAJR/F4+bs9dU02', 2, '', NULL, '2019-04-09 11:16:48'),
(4, 'manager1', 'Manager', 'info@manager.org', '$MYHASH$V1$10000$KuqK6XFBDyTJlVXUWCKdpYVVf7pebIeCRgMECzWOwHfi2dhK', 3, '', NULL, '2019-04-14 12:55:24');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
`id` int(11) NOT NULL,
  `q_id` int(11) NOT NULL,
  `profi_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `accepted` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `description`, `created`) VALUES
(7, 0, 'Category 1', 'Category 1 test', '2019-04-06 10:51:11'),
(9, 7, 'Category 3', 'Category 3 test', '2019-04-14 14:18:20'),
(13, 0, 'Category 2', 'Category 2 test', '2019-04-14 14:18:12'),
(14, 0, 'Category 4', 'Category 4 test', '2019-04-14 19:54:34'),
(15, 14, 'Category 5', 'Category 5 test', '2019-04-13 17:49:24');

-- --------------------------------------------------------

--
-- Table structure for table `categories_prices`
--

DROP TABLE IF EXISTS `categories_prices`;
CREATE TABLE IF NOT EXISTS `categories_prices` (
`id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price_min` float DEFAULT NULL,
  `price_max` float DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories_prices`
--

INSERT INTO `categories_prices` (`id`, `category_id`, `price_min`, `price_max`, `active`, `created`) VALUES
(7, 7, 30, 37, 1, '2019-04-07 16:29:53'),
(9, 9, 10, 15, 1, '2019-04-06 17:36:05'),
(13, 13, 100, 159, 1, '2019-04-07 15:10:31'),
(14, 14, 123, 234, 1, '2019-04-07 15:10:47'),
(15, 15, 345, 450, 1, '2019-04-13 18:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `is_menu` tinyint(4) NOT NULL DEFAULT '1',
  `is_visible` tinyint(4) NOT NULL DEFAULT '1',
  `super` tinyint(4) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `icon`, `url`, `parent_id`, `is_menu`, `is_visible`, `super`, `order`) VALUES
(1, 'Dashboard', 'fa fa-dashboard', '/', 0, 1, 1, 0, 0),
(2, 'Admins & Roles', 'fa fa-users', '#', 0, 1, 1, 0, 1),
(3, 'Create Admin', 'fa fa-plus', '/Admins/Create', 2, 1, 1, 0, 2),
(4, 'Manage Admins', 'fa fa-users', '/Admins/Index', 2, 1, 1, 0, 3),
(5, 'Roles', 'fa fa-lock', '#', 2, 1, 1, 0, 4),
(6, 'Create Role', 'fa fa-lock', '/RefRoles/Create', 5, 1, 1, 1, 5),
(7, 'Manage Roles', 'fa fa-lock', '/RefRoles/Index', 5, 1, 1, 0, 6),
(8, 'Categories', 'fa fa-folder', '#', 0, 1, 1, 0, 7),
(9, 'Manage Categories', 'fa fa-folder-open-o', '/Categories/Tree', 8, 1, 1, 0, 2),
(10, 'Create Category', 'fa fa-plus', '/Categories/Create', 8, 1, 1, 0, 0),
(11, 'Update Category', 'fa fa-pencil-square-o', '/Categories/Update', 8, 1, 0, 0, 0),
(12, 'Delete Category', 'fa fa-times', '/Categories/Delete', 8, 1, 0, 0, 0),
(13, 'Manage Categories', 'fa fa-folder-open-o', '/Categories/Index', 8, 1, 0, 1, 1),
(15, 'List Categories', 'fa fa-list-ol', '/Categories/List', 8, 1, 1, 0, 1),
(16, 'Edit Role', 'fa fa-lock', '/RefRoles/Edit', 5, 1, 0, 0, 6),
(17, 'Delete Role', 'fa fa-times', '/RefRoles/Delete', 5, 1, 0, 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
`id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `question_categories`
--

DROP TABLE IF EXISTS `question_categories`;
CREATE TABLE IF NOT EXISTS `question_categories` (
`id` int(11) NOT NULL,
  `q_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `question_price`
--

DROP TABLE IF EXISTS `question_price`;
CREATE TABLE IF NOT EXISTS `question_price` (
`id` int(11) NOT NULL,
  `q_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ref_roles`
--

DROP TABLE IF EXISTS `ref_roles`;
CREATE TABLE IF NOT EXISTS `ref_roles` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ref_roles`
--

INSERT INTO `ref_roles` (`id`, `title`, `description`, `created`) VALUES
(1, 'Super Admin', 'All privileges.', '2019-04-07 15:15:21'),
(2, 'Administrator', 'All privileges. Can View Dashboard,  manage Admins & Roles, Categories', '2019-04-14 19:51:16'),
(3, 'Manager', 'Can View Dashboard, Categories', '2019-04-14 19:52:23');

-- --------------------------------------------------------

--
-- Table structure for table `ref_trans_systems`
--

DROP TABLE IF EXISTS `ref_trans_systems`;
CREATE TABLE IF NOT EXISTS `ref_trans_systems` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ref_trans_type`
--

DROP TABLE IF EXISTS `ref_trans_type`;
CREATE TABLE IF NOT EXISTS `ref_trans_type` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ref_user_type`
--

DROP TABLE IF EXISTS `ref_user_type`;
CREATE TABLE IF NOT EXISTS `ref_user_type` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ref_user_type`
--

INSERT INTO `ref_user_type` (`id`, `name`, `created`) VALUES
(1, 'Customer', '2019-05-04 12:54:42'),
(2, 'Profi', '2019-05-04 12:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `roles_menus`
--

DROP TABLE IF EXISTS `roles_menus`;
CREATE TABLE IF NOT EXISTS `roles_menus` (
`id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `menus_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles_menus`
--

INSERT INTO `roles_menus` (`id`, `roles_id`, `menus_id`) VALUES
(65, 3, 1),
(66, 3, 8),
(67, 3, 15),
(110, 1, 12),
(111, 1, 11),
(112, 1, 10),
(113, 1, 9),
(114, 1, 8),
(115, 1, 17),
(116, 1, 16),
(117, 1, 1),
(118, 1, 6),
(119, 1, 5),
(120, 1, 4),
(121, 1, 3),
(122, 1, 2),
(123, 1, 13),
(124, 1, 7),
(125, 1, 15),
(126, 2, 11),
(127, 2, 10),
(128, 2, 9),
(129, 2, 8),
(130, 2, 17),
(131, 2, 16),
(132, 2, 1),
(133, 2, 5),
(134, 2, 4),
(135, 2, 3),
(136, 2, 2),
(137, 2, 12),
(138, 2, 7),
(139, 2, 15);

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
CREATE TABLE IF NOT EXISTS `tokens` (
`id` int(11) NOT NULL,
  `token` text NOT NULL,
  `expiration` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`id`, `token`, `expiration`) VALUES
(1, '9SnqRV12+sjTJS4dKUxiW3qeCSpge6/s+fyQz2qJL//O1HT/8KxrCPwOUeStwPEXExGDr9mjP3rqQMRJNdQVyu/03iPQOZK7HJLBn4Ac6+QJfA9KwcougYhTMDUzmieXSwTCOhYrrKhFsLfxXL5nNyNjlTCsmbUo4YpraPoEmBVG/76tTAjmJGvhpLyK0vq4', 636930822575627154),
(2, 'V2YKvMKETqW4T6Z//sqs8+z7s94SUvUNTvs9ZgDFnjKOPkJy7AVspHFQMjbKXfy9AuQBkloF+OLpXQ2tJh+lKH0VEsOeDp+0EFbS+zoLy//+kV47SRgXkp6nZ98o6Dy0ju7NjwgMdoZMaYA1sFRxxTBp2hEQZcUHJCK+TzLS/er3x/mxd6fQXlFIIdLla/kj', 636930824978303937),
(3, 'pC6JOE5DEmxE+/ucrYWacNXWJepbfF+DQIHoWHVKconN0VxvJ/iEgPSA8vWOslDsjDq9+ApzwgsrCWRX4AW1kqKyITDXsbaYz7Cv9h1ZvaWAQluZNCv6mXpDybx932QsmqC1lqBpVeCmBvXPk8nKH48AmYbq12/yZi5AIe5ThQut5wfJdcygFSc82GBGgAPV', 636930825356451914),
(4, 'N3WFzIa4okcKgdJxK0JNUrHN6ckcC/mqXO7Z8sxGhZ0fduLMyvRKFKm4XcspUCJ4kUSe1PbZxpPPPxEhH42lhriTwmzXCLpyhvMfJs8cKRImIhmJn2uA+hLrAueHIbavbhXl9t7mqoVWP6yHWGnmLHYP/pyZiRXOIoEzsEWu2t3ynTAqogLxlxHP2UfVAeRX', 636930825525869480),
(5, 'WKFq9SvBFWbpV1UqlTnlHOgqsJi1yPsOvBbNfJDgwcGpMNa87hNIXG4lDYYcHvReLntveZ1MzHrS8eCoLbQ9AsSZtzp8mic62kyS3TPUsEGNZFOSdGk7nDkp/3+rDgwoFzDnMAQznrQ2blf/V57miDfXhF3zilg1ceDT2mBr/nlsSCo3OG2KyEpQbEEtMwn2', 636930825918032444),
(6, 'HWG7qoak+6VZVndzMDKkxwT82M/AAzGO33KFH1Az8N6dMa1CBRPriOOEyU6MsEp5JpkWpkq0e0tlPyfDRCWrYuQibMljFVEFsrzUWSKS4aNpyl1bVzTxOJ4D/Z43dB7ve99+smdyMt5EkdWgx+M1BG8CemM/pdCnogZ3gpy+BjikvXqgQxo7usvVzGyh6Ktm', 636930831232485751),
(7, 'iwjcX4gkND37raCH5SbQtJ7bUup/vI067abOoJxMKRpflAXWHCMpHph2qA8rj0GRU5+zLSKzNScepTOJcyRIUvsqvBXQInb0wDcqKfTEsxHInCr0EDu9TImX2wrLmnehDtTNgjagr7eOPngB6Zq4BJEVp758oGpX2fgIdMRrW7MZL8Jy53jyz/x0gieR5zAt', 636930832785049767),
(8, '6xHsW8aRYDb0P4WdzceLGI6ar/TGI9kxkq5irndfSPi3rQzF2Sxxx0E1d8XIMS3b69c6gKEm374Iu/nDonuIqsrnOqm0KzJSXl3O9GgB9D2quGyV8BRbX9i9YsxbKpf+BsTSye6QZiBM7k1XLy0RoULvUGb5bmPHukzuFE2YegoBQU9+kyYKKlnAHq7agApv', 636930834563058790),
(9, 'C4A3MAUhf6Xz+8wO9mhV2XOy8GfWeckwZGExTze6DMHz7dqfuPAK07oOrwNvyMknLn0Unqpv5U6musUhDU89wRIJyOYo/KPiklLPPrj8UTPq++bQDQoe5tINXrjEk0V5uKmGCI+jNTxRWN3uR9vuCfoe1KDYeu3zMChzfd0XOuAFA8nX2ReoScrsxZbNFO5z', 636930837862423807),
(10, 'SyjArDObjcxpbnEZ7fFljnKcrndfBlEURpqlXb0d1oVyyasR+0xonPXD1pivl77NtDxAyk+sIF5U41acP2MNY3sFo6IWrUg/EzTmiYaFzuLQfdaiGDh4ia2R/KVbiRJ2vNiZ8IaaY3M8hluUy8vodtP/nVnbJ2FY3md3QvydIf6NaRgtTLrqn3FPU1vplPFT', 636930838751890515),
(11, 'JgLPBvvZhoIjZOVTlzPvSAaD2cKTEEEoCDOCPkKZtaB872rb13S+kNqXm8ACnRqhCo7/nfoA/M909S4U2Gt/Eysg0j9DJ7LnVgPW7wIjRqk0R1BbkAvbYCoa/7xkd2aFw2ItvcFVi7rNKc66bWECT5Jw+IXIj81F1/QVJ2757LXMBLUUSpueCgEONQud7oc/', 636930839596208667),
(12, 'FhG2HAbY0KNmibMaAG55gSmQ7P3k3rVPm4Pj3pC087wSAJOfAL3vS77t6j6H0ISegK3Fegk7k2X94YDEW/GGTpA2r3g23bSx28LM3YkK647GIGFIz2skavecfnp0nYSxSBBmDDAde7ztmixlGHbkxGPbh/OjxaRRpKf/4lq3H01tQzktaH7lZ6tggTZrnygl', 636930840154241895),
(13, '88MP6zyn00YpsCAy53Dbf7oUpd87MKA7JtZeV9vOgxbDGWPxMDShnpXnufNQgMrHi8yE1By5MEjSdbkmmJK52RMrHY3+M5HrxvN8mfQaE1feXOFOz6UnSaJJWlCvr8lRCvoTrmplSQ0ZFUPaBGggFYLQofsl0t4Ohmtr/E1ahkyIsZVNzYu6Oo+HzTKCVyGy', 636930840517589127),
(14, 'Q4t5z83c77Fel1cKvFDpMwn2jMPMHjAqAVzBcGTmkgQD64sWatf2A0tiTOXGiMlcxAMOJFmwys9IEB7JbzaGGeHazf4dmi2hN3YBGmsVUh6LpbQGlVS3JUrIeXmISqfgjeOcFrNENdxPio2vfLtDiOQP5hQx19d/0A1jmu498Y/wZjaA4Jn1RhGKKumKlJV6', 636930879134193172),
(18, 'LLJJIHdjexncJAFA2ntU0aKBpVcLthGf6G6b8BIh2zhqoiT4M+2usabFyp43EgptPf1eGo+837fjNIF1mRUVMVC8paBo/zkMKONRtoJ9BHcsi08d6PidJBK+H0PgWcO8PGXu3BESuahbW1TqmQvirxa7qzqI5XeZWroDWOUuPBeKtKokeuQPL9gQTZveRGiZ', 636930886111993738),
(20, 'aZbiuuHHTUr87PNrl925bT0zh9ZS3X+arZVArfdqeaBC7W1W9eBQFW7xskrPPiXoGVUM1BFZr8SKrEhbIWtzniAb3SnSDPIEbRxuZzaXDkRROyt/HQgXPQtuFiTmfVLwWJRrRvshAQvEPRwsgdLoRiXZ+JXTgqta+avBiTXC4jRsnxhn8GEuEVqQ2ilcAeYl', 636930889248228436),
(21, '1B5hnuUW3Y26nnk0BR3mVkdLMCEAuijdiGOyv3NB8I6AThVb7LlagsKedPUs2sbD1hEDDuKJcTkP11jxY2+bkRKcDTDzzxjob2Rb5FiORDlsDJqRZyLDFyNCmtCAhRv1CXVJRguuDs+CCWB9OaGG2I22VgQV5HPu4Jn36CJ8V2DtJfh9ynB/a9zJ+jzo+gGa', 636955250087451467),
(22, 'Pmz0RjzbNG9SHTIYDKwU7YxVGwVskuYnTH+59WPm3iNfpR7mA30e846QosMGC7Ycn1CtdcQbs7PxjhqCw2o3r6HPKKgnOHIUdvC2JXLZdN5GqOOqcO2z3bOiAobeFMv5frCXL3NIfqN2g2BvtZqslsgZt7k1oFihxB0p+q6CwF3Rq+qTYxaGlbZHh4Fx20Ej', 636955252765760760),
(24, 'CCeqZgEjeV1EKHpesKLqh4nu5Ba1+kJe6r9qcpwt21PsT/nW6Exb4fi3GM3lE6lWrcv5ORhOt8C9PekuTqhtfLW2wy/urusrwJsxlaJwoc7po2Fg2Sv2xxEeyVtyFa4aI/yp9VJO+wipJkf+E5UsBd14h6fxOZ5uDsbStMP0sQ+Xx11uoj0dGhSM+6z31Qm9', 636955256829805236),
(25, 'G2uAD0ezr7sqM81UoYWcjUGs2CAKbGmQAe7HY8cq1AuLHo6wPVpCiPUkmLf/USJ5GVVIrG9wuz4JkyqF/KKrrjKzvjo2CAzxLf3TQ3mfl/eoYXFlhPyuV74miHGLHVRiRu6lIAC7JG0jjp27I0qJj7ha5D7qv+56Th3/OEtBzamDwy7OHAysCMtuvaruyqkP', 636956136631127586),
(26, 'OeqnKMes36gIgQNTiD1BKVqF7dG3gadWNu0DBHSAvG99fnjn+kiUguXOt3MFED4VrOFkmdL8nRH3wz2gNVu/D67fvtg5BeQPWbQX/n6hdQ36gtr+UkpfltLTtuYptOE8GPtufDwDmyMIWlWhYZvzurqANAmNpHBQ5vT/Bopq1cCjgBw3CmY4AD7FeKVmqMMJ', 636956140310860270),
(27, 'EQzXE3UhESJS6vFYSJvhRXWGJFr3tvq/8AWBWCZ60d4kVG8pzBYV6aRT77DB4g8cErL3Ta1rXp8dWKOraRK9m/2FvcERWQq5gXEaGrzKeW0yjI2arX3Fbvc23gwm32isXOdqh/xTQhLb1pktbgmt/9CFrDu8Zb1DKgb8vQzU/S01umOUwHlBoiRu7lgQCUt0', 636956141829414740),
(28, 'RzEtK/5IGr2ldv1vDbM388fny1rzY/97aX/Fol1i8/WRiqa5C7CwgH6PB2W7mUWsvZ93TJRyO+NFEwISb6ioZcRsVI72iRw+ucp5GWQxZDeWK1Qt1ad93r8YwGXYGk0KbJpbOOXH41KPP7Pwm0O/AJk8mFxgodt27NdtKE9adzZscsDu+XDoIBKMDGshhu09', 636956152192000802),
(29, 'KVMHqCSfSaWCaSlFty/rF1Q4KqI5Ph708bCrivH2xramtal3FtG11EBEW/qn9Azhirujyev+VSOowLdMrNW3Kpc8V+olFcBkXmZ9eaIadc6DONWwqr96KhBk2VWDngD71wwPzWp2IRcQ6nQx7/4DsNxbVux7twx+I+lrsrLo0HROakaa8cv3jItsn+Ea23Ak', 636956679245618602),
(30, 'z7SvPOWs1gzw7cEjtocGwUIoze3YPNMEFLkGtkfIAc7rSmNLTRGpVP6KCbryPXAS1aDn+ipt4objJ3jYhoJBwcDMxNzu1keGtj7ZvjbtfBzrwzC5WDhFb5jvywwyTWR46A/fwwFYgMM2ahDrMD97uMSCh+CRkK8omOpqGTYMNw8Einoj97WnulByqryqs3R8', 636956684435062108),
(31, 'sTz4gqZXD4yH55zfysCcU+nyFVDdpzYFFy5AET3b+3XPlftdmTgVg44EV6uWpTPg5g0uoq5eAF47t7Is+U5edeOnMsmLNLZtteeDATh9Ul8ux2Xs8QnQB+95sG1ypxMWb0eAcbKUqW0uzG2WLdv6HRZEpDvPdRtEOz7S0ZaCGkeV7wM5aLnjX3Zxin2If5a2', 636956707683318222),
(33, 'rnhHcE5qovFjaTObQyFipdukFWoO2fUWHK6jy7CaElk3xRgFQsoBVyz/9phefYmqBJC/HuYo9a5RZi3VC0taRqZv156c7pOSRLi7tZ6DJEvTOwAkGfCL9CJNbnjFjrwrCgYOAsCH/H+BCTnBtmYHBaUDzkICTi9ilgyE/fDIQZ/hZBsFxPDcCJXgftc4W5Dr', 636956724692115963),
(34, 'fFC6AVrLuSufSbvDy3TorszAc3grpV+HNdoBVvC7ZvadawoOKGBQo6phu+iRLl84ILpn34MPJeVZbYFVuJ+CBMH6JdYAIantSKFKOMX6Hvae/dBsC5tpZSWKIGMsRS0aM6rJN35lLzoyItdeVCZUpRtOje/3wDHi02f0P0DCh1CXLLxGZbMhaKG7VF3ZVw4P', 636956734751841066),
(35, 'hN1VtrcRlNcwpOA4GbpwfgUf8pSvYrKYOAMSRnc3Bkv9cB5ULO4jo9LSqe/vXd/Booj7Qdt7bzhsqmRcTvSgg02KUri7S4imikhvx6+f9fs+N63Wn1fBzlR/9VhwDBB0/dMulm+Eoy2F9u3uJXkNiIJQkoi5wQQbvz7NxyOMA8rgNzKR1OsEHjz4oLbwTOyE', 636956735445355241),
(36, 'V+85o+ZtW0cKYUgNsR4bV9EDKCnejssUhpKe/k0/Hs5cXiHkyThhNqx49wuU/wDFXEwWpGulgsfbBDSMxm5LLsLGEbdud3KGeSGcRpVCqyXGNkIvkka1PllqcwGYIOOkJW5y09Bdbp4T6EqarEks4qSSH3X0DK/f3l8IYtYy0qOESpeLVoQEFsOpQD73Pc/T', 636956735926920845),
(37, 'A5CGivUYwmASYFupz+0BZpAQ31XMNiJo9ALhuyURkfWkjiF3Ro4lNMl21esaYc1ZTNfjV0993MQ32EbKyrPC8wa8D0dDoeQ23/LPc0OfRA+m0RCqsAz7XCe5sY+BOLn4mQmvVD152V0ahhCw+QbtX/mQpbeinENsFKmOQBJcqSg9/+cjZeKZ2MYRT8MGh3ms', 636956737884546365),
(38, 'y6sNG74d6JhgHSpGTUejJuQIzJn3ARS0BfAJS+LFx9il+fbbFlPNvMqDclSdqEKc/8nwPIptJcGLTLhMDKttPeKYPOIRwvC6ASzj8UkQiExgu8WnH56+huqixjbgeBXWJWN3Jzd8t9l2wnQQ3hkX/ZcQBgeFgs6foRRCDFCZBONcVe4ZWkZal+06bQP8fsiG', 636956738561297614),
(39, 'ldz7ihWb7rwKRTPa23PGoaD4wCJur/tg3YJqf8LGpGSGY0Qj50OKsqyd1pG1ozoyUTDaFzf7babnqEtnJfFRiXZxi1FJbl7+WJUhx7lfxGit2majUE4ge4vkixdu2DT7VUcjQQH+GJ0eTPO64RDBFDwMYgj2hMbmGw6RXKF3v5MXKsZ7XHKyrUfON+4U1ypn', 636956740569835934),
(40, 'DZSvV5h2IYWSKxofvucOIMqeZl5Tk5eeSnOW7iVqlDq52lcFpxG4Re6C7vYXsuQ4SvYoiR/Asjw01SFtIvSZNC+M/GMTDutX9IBI8idK6bJarCGVbIKIulqBTBDZZ+mohvuINB5Sy25afAZ2pbcNP5op7RWyMAUJzffTGjFZM9OAQ8rRSEFEQvDbI0HZOSID', 636956741710318582),
(41, 'grGXx9PHwstC8ac5zXn39DoWmpJh7FAVtuvThPdJYjah2VzjuSBncxDG+z/EAfSsJeZzo6FRK9oyJrb15trq5UxTn1bKRaN1aBuki/siL8PSVqW7w3MMRBevpUMKTIzX0BzuSuvdhWRbd50Q6VsDyjahnxeiaDoYGX6dHra94CG1VxGcQPe9dpWYq4Uc521G', 636956742406402452),
(42, '8tVSn1qsTzxOSuUALAKNyKLpK0IW07dKv21YQlDkcVzJJI4QqL2yhJDuuuRTqTWnYA7nchvYvrPHPDpAHS7BEahYNf1guF8afKCRmpLaqMmARa7u4imcjkLApVfrbSpHEE6g3Y/TCz+jmLfSRPZ+IytU08wRniYU5XBqUlgZCsvunL3k3tbU5bAi3rrR50uS', 636956743997010810),
(43, 'tDKNq3bCE4M5zdffwMAaMqyp2D1EwFFlmBPHEtx2Byq6HS0K1YcpAy+cBVT2618FehbYfJkWtrAKTNmJhigG4c9b6U/2XxE6CYrWCrqgPCUb3e8A63niz2VLpdeGeVLLPsNF+TCkydJx+8fjHJ6FaIq1VuO4+1QBBL4jpyr/gQyHS71viB3UjrmM7VjNfhQ1', 636956745475689137),
(44, 'QbbmJ0npIhvgeqt/p7ZijcVJq04gorsW69LJ6FOt5rDZrheECYAbt3uAXnbr4NHz1/RlR4hRyN9waxlxDMfnO+jMAEcCiUTGhEDcKT0XuGM4JkA25cHXGvrlbIGFw7BtfZrJFhCgjWc+wE3Le4w+LH8zgHeFQn6iI1NTLh6ueEI7SBJdHqPTfZCCVTaTYF1v', 636956746853500322),
(47, 'eQ853bsMtxKSK23iwE+5CzjsqTlOcpqCjnGoUqfpfBrJVes9+grIrgXP3IK/ZiUbNJwWl3118tLseACcYLjrIcctisnfHjYFhkJrrFSOS6ouaDnthBlTzosN7CxHIoiuzasQcmAhwnCogDiuuQ6DG5Q0avkl71q+UYTBXhwCccuBXq264BFw1ffr5yWK8GWx', 636956750279381686),
(53, 'amhd7EnlrodNDDojXwqz3HWJTQJ3/ZVlA6oelbcQClwiLjvcP193w5BL8C55ucVT8luqRQ1Lm5a74/6Fa42hFAGuYFex8mK+vrm/7cge5wLfHIGNBc4enzdbKehY5xVKjLmm4bzsvhnthkah1vzSZ7u7lTCMOkI7e/4q7kgIFyUUWN+1hjNqMFre2vKmuYaz', 636956806789101104),
(71, '3VBektkirxWLqT50ZJxtVltoBCDAj6IBadyFHYXdd5DXmllcHTdxxRKKX1tTwMWRLlL2oGtB3yMIiZyqOVH3+EyhTfBAm/Nh20EORyCxGBcU4KXeIrbqCN2NJ/Gv42Q2HKaJ30HtO5vjUJWycKpku5NYkfd6JZcpWlmmNdJbyfoVxLF2Ezkb6Np1LkD1LqEf', 636956821683536413),
(75, 'kCIPiRrBz8F8ghgGviA6w0Jql5kznCXL9tSAwuhPKQ3F+lD+XVxy9JQ4/do905eqlSP/DeeKW7FFOm2c7cFXwkfC/dsYmWAE9yryDpw7QQSHF0Cd7qWxKZZOMOacv1SWdB8NwFgI4uMYGIG9Q/qrjzWFpn0HZcr1lDEEmbLY3otoC9xluebvoCBkCPOlVJzc', 636956823961630785),
(90, 'yMpxn6QkIJMSObe9U6X1/E6hJrUstUDi5xFiIKoW5GeiQzf4pILPsHvnXGl8fXJ4wIUo+y6c/5bZEEhhGu4f+GGAAeJypzjs+j8EpjpU9yNAZ6AUP/luYzMEFD130HqykZHfxUYkyUmZWurV4/NW1rgbrfFgKgxcbeUs53KTdV+CoHHiOAHtp1U1XHSkpUhS', 636956829000841668),
(92, 'nbfEr3Ed7fKnZQ6lQdCsGdSXPew7a9cffIc35/V7TRqgkJwpzf1p5hl4mTBNMVFKR0GQL/tDktwW+H2B+HABV+n0TudesiqtmIXyv8XpGo/4Z0mP/hpmf8/IpW4uhUtDOaHss8/S8x1PTA7zYY2mme5ObvA4qXQEWJ1iiZSVZc9YdN0nWeGYSPNbryoxCbSz', 636956837446192231),
(95, 'VNaSjEtnWir2OsXDygeVOTluqJsSKwbYbBXDjy4l9gn/uKG2TvTDWCCzZCZXpNmNUKcHYCKjAfUkWpDXcrLAxWDqz8tbFJFVLrDyH7FvXpm7Cx6OdFdTaVD1zyVhVJjWfu8SvLy6db2qoPvLNQEAFlSpfvad9IE9AzNHa//iwa4+XCqbqWuettKp5aVuXEuA', 636956838524783189),
(98, 'mmBEV83dweoUkIIdq4QCcQeErvgnzD3CqwjFu8RZQm3UNSPIfG6B5fgl8A2Q8v35gDvLv1aphhSs2CnBOCZh+iIWywrtNoOrb78xRxln6Nu1clU21M5ZqbNm87JSb8MR+iJqaGQbpZWhtqjToiK53FrGBV1aiqqm1r3KeHPiYfXt31rnfhm0JzamKDjpH2u5', 636956844825489327),
(105, 'NHpUWqzRNC7jjrmKy5q859wrKdCF9UUeQ/N2+UXjLZe8Fh4rGNqmaaSdDdUpXDG+jPB+z99xcjd0KhkTBW9uHXlirH4kjk4nz4S5ylZsS3VDyOfU0l1m8a/qoSCEApPX6oz0uSv6IV+Emujy91vN27A3qbnmPZ7zVdM6ouapKn0yXZW4rRfLNkARDvn5FtTa', 636956847582424821),
(106, 'C2kIkU/Ak/1TV5+PeG2VN70qOVb43GTK+fD7SGbFPMBYAb0lhNRsVBzntm2sFhgCPOQNJRvu3JWwLni4BEakjkyd8MN+titeHxoA0JhTIZ2EW06HAGipmErfhzvL4E5SMY8DjojVQvy7wTVv3rDc29Klzg+yF5Z6OsgSFGnHaZiBwGLbNJVxtlrVXFbb/I4M', 636956849959035710),
(110, 'ARLeWM7wnFv4xAiGMtR2no8AeyDLHbEX6Y6BWlji39lSvyFnzCvz4cq2O8xnZ0fUZspos6zEVUdKoPDraueXi79Anorkodh8s6n51Eql04K4cyerLnRK6DP3orCZIOEZqKAh5Spd77xo099yGNLs7o0kXc04B16+1z1TXn4wLoZi6pcEAaAgz/JCFNKXkfgU', 636956852050273662),
(113, 'olm2qhUM0DyWi8F1w2BXdmUmyOFjS7CRbpSmORh7mNctmRxbEIuJWMXfBg9Mp5ZZh3OTfJZ3AhYZQrxtZX/43ui0FY5Mi82Pb1ic19ZMonKI0sPoiy/TdrcSMQ87lhWLPneBY682gM783QlHu7lvoS7CodHQcwY2DbXVn3HtHp09A7IcKLuoLfFQDGeya5Bo', 636956853842647217),
(115, 'FNc70RK57AoWdQix0cg0Ogz8pp7RoL6Zn3OD9EzqCBRNSV8SHozY79RYeSsOTVSYTGd3OwxFbSZ6MGhxzV8ZrWOS9bWSC68rI5NyVaMp5B0NXTnqwmgeBhljqccm8ia+bDPQYznOl1iu76i2oDfQ230vIs56ze7KMRsiqTCCjHN/Qc41NZcyumgfVmPyy3qx', 636956854758221739),
(120, 'mcbEp1KfRMA0OrxD1xuMVpj++IPCqsoDHAhWwo2pg5GCMb+mB0xdMv6QAHQvzgFvLIpWavNZduQOyw3fK95Xu9Ql7pDIxhs4p2Jxas4b85o37LPl0nY5jTp05/LU22apvyHfuXYiKCIy95z1aLZCIHG4sv659r58uiKzNw7iBcY8tFBo1i+HX2zIoxEeFg8m', 636956859005181289),
(121, 'j8ySmW8eOe+wijX+FdXhiBHpTjHSgtuZUNqBA6vsY/CXpkt+7x6odcJyrABKb/MyoHD8vcX7Fiy8JNbyRO+Pd5hn1zQl17D9UvwsKZkrK+InUj4TjqdrjDCT9t3zuphPKEix565tXfBnQFiM9qEKBwJsvYxQGf7He4MLrkeLPjcbP4kwXxCKzTYxbZ8qIo1d', 636956859062779158),
(125, 'qaml39VQnvlfx/UHCSjVET+uhPH7Ky1ppAMRTRNpBsqTT7CeAUX6E/1D/AqadCmrq3BOixI30KRaj6HkX1Q7jKKkvqoFQP7jW60E6a86KQ06D+IDPaCMAnzr09EThx2F7em1ZU+Um9r4pSDFdNXSWe+un7Atxr43NsRF+27humGFiERGvyAsxuGDXRm6JTi6', 636956860615090908),
(128, '5dMkRluHwwScwcoqOvvDC0LoY0bC/Qb050okRCTYwLa6HoBR/dlgurRlzVMN+8RLRiBRw1JTH3tdXBO+VKq/M1Ll76jn5V8aJ9cPKFP1awe9U/s8+lDGWK5xAU5PnKAgrGZfQPVboz+SvwPHNCuqOgSuymwlT2sfXq2AgheggMQaaWhjYMFgo6wpA/mwDvce', 636956862692522572),
(146, 'xpDKFFO6wZvTJaEhmKw+ihsODUjRrmtPaV+EV5uLH5Bz64tBl56FgzWFe1GrpGQUhiGB7IYpzBmILK7ib4RqgZ5BvR7VIGkuVVq5I/1lGOIroVbDWhzt6UY6lvSqmO73u8kFpso11Kuq89qL9HbeACNnXG6zedpdjSWURIqhT3/J5x4j6hkKVWlSs2Maw9KZ', 636956867596377506),
(147, '77YyxElszoFnsTZhZ79DXwYisiqHkLe2+U0jSy+0jbTbOM3csF9TJXPjY7hmf+dlJ74LNrAS968HaABKryMhXGBLuR4SL2pH+xwWA/2Voad9Ap7F16vQCX7P2tgEWYazhbUyfvelSrqYDxIHziwheeLtyN59TZEXn8JY35oLhHBb50XHbLlP877hmYffLX8Z', 636956933745233168),
(148, 'vw4LiwAAB2klYJ/Go0lqV+bY9yBqcyLTkzGAYYxymEFMk3NmKfyrtgOFGMjDr33gbG+Z45oz2NV+LQoURoHMGOf0dJwYGCpmjRJsiGQXgKQnyjjl/QzMctfymLUp9QMbwlb+BZE6wc/GZf4cLcrDuwoCd6KkMCpM5BOeJ4OdCZ4+sR/hrtjw/Bv2oJX5Y0uy', 636956937917594127),
(149, '+6bGw3eDEMOu7F3FDzKXyzaDH+vwOSCKqr4oLoMIiRdtw6BCydgs+9whLYjpoHx70JeuPMDCcSQJypMdqrKw56IQAMU25DPuIcyG07V6LZ5mJdIBI4QCBtkkQ2UEL+YDnhgdSNFZdKyJSDGx0cfyxVP1CQKZTigq7GU0yrGcasz1ao3ieoW4BhFyuF+TUgbh', 636956938739569500),
(151, 'BXIHPb54DynqoGkZ9qB2E5YOiCcGSF97oioMoC5V6eQyBPGuUnixCJjhvFZXqUqSM0WcOMnEsPQFomWgsHNEmNF2mVmh6yGS+kXLVrkwM6Lst71wLXdWVun4nmqtiTTHBLoUNp1GIp5LcBmyfxmp+5f89HiG/FBdANGIZNoFzOsqNMGu6aw/XckETwhrwNpa', 636956943910434868),
(154, 'yKDQqoHWjF54rUj/XRKT/ZiQq7JLGKCE4oaIg3LrJDMxjqTSRMyvHDSgMcU0JHh7YaLnnUqm8VdTJyYe0tJGWrG99KCnY0JAEGnv8asbXCIcGBLjO/DN4E56TIrTzvMSjZ4dSKVGKJx4JY36viQeU9MZNp1e3plBDRML6do2jF1NbqBWLuMpXWZr7XlhvO+s', 636956955794160580),
(169, 'Wb3pzQFZozyQwthzHT4St0sl62kHMRo7MKE/g/7LHzwwz4KGPblY/ucahmKCQzhEOtH8wkuXIKDbamtGyE13TbzXWxLxSP1KvGYTP4YDhiFAmKuAHw93jRiFUzE+e9yEOeBIGPCeIjqAJYv1KKOiHFLZCI5zJLmDJtSDtnw/QYjQv0jhD3gZoj9AOa0OYARd', 636956960219087280),
(171, 'wlTyxoq89C3nKDNeHKVpPvQl+ZYsGoUAk7ZU7nl6SArfldZi7uO5GCVCMPRxqRN5P8VC22gBB5IUhNCpVk2ItOnL4lJ/9pJDUnA9BVldaKbF9Se6DQxZ9bMeXvBpTLc85IE9OUJIqGL8ZSuwkIFgW92Juz0NSVfLeleCpZF1EMvw+THKfUdnRRufp/j19K6m', 636970814684576296),
(172, 'o9/PiXcIOZB6c1R6PY2bdBqudC8Mk96shlbDuWFLQJBLkOoIZzgw9t/vCrkehW2GymiFB0ypGEa+iffRRhZUSD+aGwq1u0Sa+yTOucfn96bX10xurEwyjZW4HA5KK8ogkVCW9ZF6F6I7P8hOXczAo8SUdLsv0kZdIkiF/fDrcfWP+iCQ4LFB4Eu016XGKJ0k', 636983752260631213),
(173, 'nyFeRjLZmxQdCyPtlHTHa1oCzC3uj0cT2O2OxcvnRWYAVX9VLto9qFhqukCq0v8VrMmOmFaZgJ9TnpsYhLQcgTY/SLoRTLy01PdTKz8+wPZgq1AdX2afuKAaQdzBNJ1qhHsuvg3QdnWAwJVVJpahKwLx3Hr1GOzevJKNfK5PHDaEaS11bJ4GQ+u7YICGmyu1', 636983752251124036),
(174, 'qZ6Nx09sffMjebwtLqbe8H3rO11ugvyl45HaD3L4Ce81dbLWV5lh4gBuN3PYpCqSjD17FZZXJ9bG+6YFA01KLHZBrnw12Ue+pEIlL9HB+/vxKqh0te6dnXS8im9cfIhR/WywA/vxmFM4p7fq9R4UXUepiTrm3APS8lpb1/2+UpymkT0CBkpvjMArqofPDGtt', 636983756270403341),
(175, 'B46Y/QpBOnOHoUMkqVpdsdy8RY311hB4GmsZ7+vu0WfCIlM1bt3IJlAqCMeMe0+PwyDfYADzEKzqFidVUsVJphQZNhYY0cquEOJxCZHcUeZPb3rUNP3wiOZjcL66h8jOOnnjfsfz/K6gPEjFDvHukJpVp2KjD4Rq/IfmgiacMBx2XA3/bN8XAyJEgwCDQLWJ', 636983760486119809),
(176, 'gQKtyEnhxHqohcOYylFCeRrKa//Zr+O3UBvzo3hsMag5JyOog38g6JnkzhXta0pGqATbHX4SJJTX3fbmSs61RmMRUwzPqAljOpg0dujnEIwUJ9Q44Z85swdnQRsbCkOEbU50gNGM23/Y09nwF54AZ2JxT+G3NpSzmvaUbhvjFWveHXWr8IveSuALoSAmu3lT', 636983762925162822),
(177, 'OI8rR7KuL0m4t4Z5g3upv4mraBz7mUfQ8A+UxCCs7Svpj8JmPR7RUYudmYIFYnBW3m/X+HMz6+9IBshyRJfQ8llAuW97GYuc8jlibO4shHYugoVpSzSEWcRojcKaCGrC1+yLs8ftT+FO2h84Gt7G4lxAqgbmvN9D5O877HJNdfQcEn2V3KJgr+Yk1h1jfpJF', 636983765363917547),
(178, 'VBep+EMrOJA7ALPmvQ8yf00qFSrXnu482x/lEHA4/c9yT025yCCPrJkoI3lFkQoCIgHAURnm9FgM1tCP1Ri7ORA2gcyeAy655M2E8t5Ec5/6cogixj8rsw2/IAwXgPUvpJ4iiGcAQ4oqH3p3WIQ1TOGGLlo7vn19cxGLMpT6QI4nMH4byBYAorW2KUuOdPHK', 636983767782325733),
(179, 'JuBpOI2uQMXk3/T99ANWLeAXst4a8GC1ibiru7nFjU0vyJ1DsklZDYCkwm2QRlDIMMn0ibX5cA1BQO50j8gNRog/sGZj/+bVrBl0DZYdoC4ZgSYZcnGyYWekw/UOaWtkyLKI/CHrdh460nL0D2BxFvqbSiZz7VXDxNr34vqyOypY/xF/ib57zPivuaa2w76b', 636983778044975117),
(180, 'GztiqhZ5BbvbamVCtERF+OQdtT7kLX7PP1F2tspOgjbwE88vzQfBMJVVt0F45CXG/rC0E/7AnmFU6QtEhEdnc6aFbcuxuCOWh30c8t/bL4Gv4jxMLYvb2sqjMY3wNodzyo2UNoUnRpbPa2hhQecSScTC+YWFt9nDCZbWR121zw9oxUBPV84YGzi0utjZWMIn', 636983779471201216),
(181, 'FDd1WeHoBOCZybJBvEehzoOAcALtRvB73G08WjcotaqLXXHsiXvtV5T+M2A/BVQ8RBF1QSDZuAvyPl/ay8vzc9eFzM0+K6GNrtumZ4ivv+2qjZxy+qYlRUiFYWE9edO8KC+c8efeabWGhjZcvIliSixf7/m4MRpwST+W55YaimQdKx/LkXCX8lzkV9VbcYbZ', 636985508511048194),
(182, '5Mi6hu93kn4hFiAbHV82c4+ss+pv30N1kGMyn1sR4OC1Hri3RIE4POxohidRkC1C4ETibV5H4QBelfsBXAg5XVHdh+SbNV5yuddF28NscdIFY6tFngwlYQTYLdbNeYeqWkJp2n5IzUtsytxoWYY1/Li8GyA3g29ZEK3jG/6Meecod6Ak19KBn9ahT5jXUQyl', 636985513976464789),
(183, 'CuItWpzkf5E2itHRw/MDeXUxDYUrk3T1ROThViU8174j7b4KZQK3tgQb9xZ1yczgie4/fD/cLPsWceGRfbn1KDDBUwQC13h3CG7Igr5Dy3UOUiibt2hf+bslU192k8k+y7+MjyYvLZdHLt01kgUkFoGChu+FQBGzNOms6jDt8R4T4p+8rG4MxfFS9oWf8qbW', 636985525505279464),
(190, 'rDnYsmVhHnWG86Bh+TTWGrZVUB8nnKF/vwxnnPEuoScf4Cp5tBGGFSSwoZV0S2DkX6nlWyvYweL6YPYsglwrKrR8KECfEM+cIfDggjKBTFuNtlqNO+NIzTl5ISx+Caj8jgMBIlKUUbRxU4fwlQ6FGVRfUK4Lyg3EL8IgquH13tWqgKsZIoEz+cJ2i+YruWcS', 636986099740042194),
(197, 'bZssXOMSFJU+FkQCx1fRSw0JG+nOYkvWH9vLN+NYTToftXiEFgMCpZgjjLoR/01RhbeRt1dN+G5PzSAqiEDhp41zq0xq4XOzy6dCdSAljOJZ3kEzamKp9cTL76iUGepcUCSmUg7E/xcPruYIRKsS81+ngpT00eC7C96ur9LZu/zodbKKtIlHvy65SLLVtIof', 636986107701807868),
(200, 'd6HqbYclHzanVy17ukrvPbM/XrSjzO7O0iUpqXNELIMLJqVoMd74JZUzBgzQ/pz3jBVHMtVWjebfx73JLSSmAEiqUl3WUyXfHgjK96ZK9l5rCOdEFvZUnPnnVuoh7XHx5ijWwwT25J6nzaynu8PE1Vp996X0fEaUeHk1TsHZx55CEgkbIUlMwaCX5ZglCkvE', 636986114584855594),
(209, 'M5eUgLY8RIU7ohgTOjTHNVeyZn2TnPkKTEDKwwNpTYabKKZSzZBxPMbgb+aHuPOVSZ2Tcx3L4sK/uXM47vbbTsXDP2U9MtLh0+IXz2UVwyOeTQRon5xAn9ru+NBHR4qKQTWZLntbo3DnC9ytUkt+vZIeq5jBaRJaR9DXS28CVbF/jQMdrdXg/oTz305HklsB', 636986119371804246),
(212, 'HXmqaXhc9hYik5SBeebpxX5/w+3FHQj2bJ6iAdry5Qe4aaSEbQOQ/YEKLycPhO1vjXW4JI8C2GNtJKCp82ZHoz+ee1u1IF5CDjTfKNRUkSBqkpJ9tzgNGYEdqQoI/CVORod9O2XTlN9WK5L/YXVJ51bAjw5YI63qP7bmA4GgMf7YNXpvWKB4JjEcskJF2UzV', 636986146673976733),
(214, 'HsQTPJBxgjIJl2vcSJIPVWADEljlBI445xzNlMrhIrNqGRoBvlziFPg8eiz8prDSv3o8o26Is9n1RYw7xMAAJek9QyOAmdSXzjEB+70ZjzJLaAFFsiUcIckqF4ox/0QunjSmbPSyCKqM2Jy9vhRIHJPcWyB4t5TCNOpbWaWsz8A0xtjQ0XO9gupCdQREMXTs', 636986157207774460),
(218, 'vhahFr8cvVtI5QGe2xzSU7FKAZMa4fBiApc5q6lujhZozcgoUFn5aw8+qDPZTur/tgT23oN7McT6BxnVbs62mmIFgUBJ84nWWwg1OVcJ//7AamBIr+u/gT9k2qbYC3nOLjZkFdzYpeMIkwmMFGMe0fVk7jZSPUUIpBg3gYEq/705QoGQ3e11gn5Oi0ZdprYw', 636986160291214758),
(220, 'D6zSrBZQfdkFD4cG9HkwvjOx6xfzn1zWrWv/2EIo+zSgOwe/XLJV7R5brol8SghE3Smci6bt1ChWVzvWou8o+XNS1IWUYhFTmdVsCMsn6T0TLISMRY904jvWnJqOX7TG3k3FcMQuR1Eqtj5HlwcKAZCuh3WFv92sL3m/yG8NX9kQkIJOQ9ck1blKy299jGBW', 636986175561383956),
(229, 'vzt5V70FUYAWn4qxmHC/os1QTk4hx5i9RWkhAtPbEkbcs4F9X8Ra5+yF016K7LT5uB8SEaBvc1weYJiVfBd3TFEncDGcNwoPvxRKOHFQ0gPmLbONYEAazMJyi/2R6QtsFEtRWcCELh1K2pAOQ7R6uQHEGgBwWrsdD0l6/tRV3au1YaGmpZdOrzF4mqKo0RYC', 636986178725068002),
(231, 'seeojqF0QrOAbxfcz4lRIZL9mNkOBRy8wlzWJbDdN5JBjjjAl6V/GO/nw8QN1tEOkDO+pNB3hHBeMMLWG/UrXDD0tnie2/Mbu9UISYxmVtOnGbdpgbJ8R29MlnETyk+bWqcfTUyxLxPSgi9n6zbIh5KRPK9dP7gzZJTJcHq1hAcE/FQoR/bLnhJGBs1gqGbh', 636986180065566100),
(235, 'Bj5DkBVIO8psAeozGFX/8n0cfKiKY7wzHV4C/vMTAktdLNDRspZ5dzkc47TjZxeWJa1SqtjMOP4M8O6lYDjdGUH8hoF5MKTfeWaF0h+RBjYkzz1u0TfOdgTed3pkrodlzng1wVkX9WG2FEso1C7LOplhSF2O29qzE+CXm1fdwP77igB2TwPD+7fuoqUn/09y', 636986183059528950),
(237, 'BB70zhJc80KuOUF6aQeIp+qArXU4s1upt2lvJWzng9+4OThjvobdGBjtWL5lL39XzgE9M9d8UB+/kSXVZl8edIAspQwpw3UpD4HKHxttJ1deVkZyIbdzOMOeqa6uWoNWwZTR1kbLFP75OlbI/ZGOV/nneAhT9d0+ew2tNnNENPcMQMJrG6ZOQFp6OKzcgiNS', 636986192562324191),
(240, 'oPQ6fWIBcHbDzgGhOC2f56qWuWQ4ywba7x+eJzNVvUJyWgNCRijAr1x7q1Wll7aLM16097HhUgCDpBvGmD2VeQdkaWpTXDkyjU7EzFclNZ+s+kPPsi3cErvSuU9uIVT7uIRjDsidAHkDAFZSH66eRbDi1cXx55cl0mfqVmf2THgWUb/lYRmzPX0Ti56ITL6E', 636986198296027289),
(243, 'o26ZoMgNNalM7Mk7lIYCUtMpa3LOh9LcYtktdqua+uMKqmpOuSy82KEuABtim8eXC4HGjDdZijkVgX+ZZrtB6pJbJS30qT6blKerLLrRAgMP2tajs2EDBwjIfDQ6jv7JJxZxQA3NqOAYyfO5+Wi9ACjb89fx97YwSFI0CktGT+uoYw1v14SB8OJxRs/2tp42', 636986251465505870),
(247, '2WPQ25d6XBbqOZjPyznDIT/tF1WTD+tIhA1kkuENXNXkdWyzcTe64PksnSIMw7YYDBCaf6Sg/Sq1o3tg+0oOpTn+3dpvddcdGKlEKSEWvGhxy6AoE75arbekdMdBcnvPILnXX/yMblTFEf4aZYVSb4LBH3A0bq2DLwL2Rtfcey3jb53lXr988xtoIi0woB2e', 636986262464946543),
(250, 'gRUYfOgU3NKtUwD6p6YsRMoPYreRDt07gF61n/XF+6ofMk/pVzMADYIayYJoYY7QesqZ00FFUQ20jphqozlS2JTrMTcMGdez/Xb85AUBT86EUN52WS42sfGT/cuy8rD7JStQhtgpaQAHKDQeOZ9FfWMoUp1lQHyLBgcG7ezOH4k9+D0q/PcFNlEyfvgWgV+n', 636986264720121045),
(253, 'gM3dptzqMBMDjTupoiYBd1uF2KbTcqidDbjPVzsKcYzoZxeT9Y+nqNNmEc7OYuHAFxcjSz010ayKiS0XOqDhJT/JhE1vqq8XkJ8Uik4pYUaIs43f8J+rhquf+HPFdckBkEB1bG3yPmitmpde8Kyp5KY3KtG3EQzT3MPPP41ZXgNMopznhYGNFXK/OYd2p0D2', 636986266124095310),
(312, 'MWe/i0qZiyM09I7p3xQ6RXo3SRlS0pHcOqo/p0BbPFfOS/1/HexVMJMWnaY6+o+EX7nYnTg+Hy818qaBKS1ui0ct/nqXJ6kX7LzIf4RP+aSg0MVK8CXiem5Xd/2maiq6ZA1PlhWabuJgx+1j/7mQ5Fz+J5Ka8acrfjZ0Fsnq2DNgfZK7A3gh4Q6NuDku/vVD', 636986297288471435),
(315, 'tkDTOrSiIg3QFHlhgXoAjAQUrH1m7EbLVOergZekYa4OX7E2Wqnqe7h1TJxz9nrPB1FYvGlWElltzTfuNqNmm1qfDYIbV2AFxiVgO0J0Y4Ob/IzoB2lo0SvpJkuMs7suhZTi4V/d7k8KIPiRTJehcHkjiGGWmLBfu5A84aNrKVFnrQLqpObppac4jOGZur8Z', 636986299775785486),
(318, '9se7rAqXnNVxL6JZ7+vLUtcjKXVOPI4Ftfs4xKBWvPbu6/XAfr6w9OSBl9zzGOTyVPqSKRZZotTeC6RxACO3FsfaoVTh0SwDvYIro2Jt0VxJfeK3DgP/eUU75nukTS7kf7OBgrduDxvNHw2mvqmf3Zlf9Yd4RWNGAk62t50WPjTx+FNqPkYzvgMhd5WzKNth', 636986301967733659),
(327, 'RPYL9q+IXfi9unwRiVRFkva4vmmhcVTbXP/47gPtXPSgXFWaaTbRqGRHw7D7kiRQVZVRRmFkkj7xqTW4r8n/vL8aGu2f0wgiA6L1gKDXC3cOlitGt2q3DLVSXJRWhxnweKyzXGyI5ZoA3s94cArbw8sJqrT72tuQDs8cZGrAA0wBWL2/7h5aGIe9AQ1SFVAH', 636987141136150982),
(330, 'c7bG/UHPuH55W1+81p3maN/eG2xFDmDk3mTomQ4Vr7tmHhxrUCKAlcase1Ge93Yzd5sxlW4Jb+qOXrFsBwqanB7MGO6fIca6WjTOzsuoI1fV7rqnSRkOU7N/Mi3xTUy0270hnHP5P9/BjlfcZT9PWNUybU+mGCljFr+DlQ+YwHIHO36SGDq9eQ9LbbDmE4XK', 636987143987487457);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
`id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `trans_type` int(11) NOT NULL,
  `trans_system` int(11) NOT NULL,
  `q_id` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `memo` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_type` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_visited` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `user_type`, `created`, `last_visited`, `last_ip`) VALUES
(18, 'mytest8@test.com', 'AO1etV0sfTIkpx5aFbytJGuneRrP9EN5MiNZ3TK0mpj0uE/wZYbrJKZkrewb2Cv2qQ==', 'mytest8@test.com', 1, '2019-05-04 14:46:19', '2019-05-04 14:46:19', '127.0.0.1'),
(19, 'profi@test.com', 'ADlvIrFc7OFxQ69oJXhxsaj8DCBNDyHcrxMGgehmWgaI4GL7mU+3fOZ9K/LOWXuzRQ==', 'profi@test.com', 2, '2019-05-08 12:52:45', '2019-05-08 12:52:45', '127.0.0.1'),
(22, 'mytest9@test.com', 'AMM3LRUppTTJ9uJhVDM+4p+DBtm9xmjeCSpmCIAlkDloMV5eAzoaEQX5ffUt+FdPUw==', 'mytest9@test.com', 1, '2019-06-20 18:16:15', '2019-06-20 18:16:16', '127.0.0.1'),
(23, 'mytest10@mail.ru', 'ADiOiyNj7dPtuUPSKIbfBLDNJ086S7FwJdg6wqoE4aifO8KJOybpPL7VUpPgTwC3/Q==', 'mytest10@mail.ru', 1, '2019-06-21 18:46:42', '2019-06-21 18:46:42', '127.0.0.1'),
(25, 'prrofi10@yest.com', 'AIalhTRfs0YlLXvEFlIKl3b8z//eSrBWDOZb7au49MCSvuOyErl75A3FVPyoUSRS7w==', 'prrofi10@yest.com', 2, '2019-06-25 17:34:21', '2019-06-25 17:34:22', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `users_customer`
--

DROP TABLE IF EXISTS `users_customer`;
CREATE TABLE IF NOT EXISTS `users_customer` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `birth_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `passport_id` varchar(25) NOT NULL,
  `phone1` varchar(25) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `photo` blob NOT NULL,
  `memo` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_customer`
--

INSERT INTO `users_customer` (`id`, `user_id`, `first_name`, `last_name`, `gender`, `birth_date`, `passport_id`, `phone1`, `phone2`, `company`, `address1`, `address2`, `photo`, `memo`) VALUES
(15, 18, 'Alex', 'Amatuni', 1, '1973-08-26 00:00:00', '0100101001', '899999', ' ', '', '1, avenue Via Appia', '', '', ''),
(17, 22, 'Anton', 'Makarov', 0, '1966-12-03 00:00:00', '3455', '24&778(', '', '', 'Asdfg 5', '', '', ''),
(18, 23, 'Faui', 'D&#39;avcio', 0, '1925-09-23 00:00:00', 'eft23456', '233-555-5678', '', '', 'Asfggvvg 4', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_profi`
--

DROP TABLE IF EXISTS `users_profi`;
CREATE TABLE IF NOT EXISTS `users_profi` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `birth_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `passport_id` varchar(25) NOT NULL,
  `phone1` varchar(25) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `photo` blob NOT NULL,
  `licence_id` varchar(255) NOT NULL,
  `memo` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_profi`
--

INSERT INTO `users_profi` (`id`, `user_id`, `first_name`, `last_name`, `gender`, `birth_date`, `passport_id`, `phone1`, `phone2`, `company`, `address1`, `address2`, `photo`, `licence_id`, `memo`) VALUES
(1, 19, 'Vasia', 'Morgan', 1, '2019-05-08 12:52:45', '0101101101', '899999', ' ', '', '1, avenue Via Appia', '', '', '20220222', ''),
(2, 25, 'Taras', 'D&#39;sad', 1, '2019-06-25 17:34:22', 'sdf12345', '2443345668', '', 'test company', 'Dsa 11', '', '', '', 'sdf133556');

-- --------------------------------------------------------

--
-- Table structure for table `user_categories`
--

DROP TABLE IF EXISTS `user_categories`;
CREATE TABLE IF NOT EXISTS `user_categories` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_files`
--

DROP TABLE IF EXISTS `user_files`;
CREATE TABLE IF NOT EXISTS `user_files` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file` blob NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `account_balance`
--
ALTER TABLE `account_balance`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `account_id` (`account_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
 ADD PRIMARY KEY (`id`), ADD KEY `roles_id` (`roles_id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
 ADD PRIMARY KEY (`id`), ADD KEY `q_id` (`q_id`), ADD KEY `profi_id` (`profi_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `categories_prices`
--
ALTER TABLE `categories_prices`
 ADD PRIMARY KEY (`id`), ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
 ADD PRIMARY KEY (`id`), ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `question_categories`
--
ALTER TABLE `question_categories`
 ADD PRIMARY KEY (`id`), ADD KEY `category_id` (`category_id`), ADD KEY `q_id` (`q_id`);

--
-- Indexes for table `question_price`
--
ALTER TABLE `question_price`
 ADD PRIMARY KEY (`id`), ADD KEY `q_id` (`q_id`);

--
-- Indexes for table `ref_roles`
--
ALTER TABLE `ref_roles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_trans_systems`
--
ALTER TABLE `ref_trans_systems`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_trans_type`
--
ALTER TABLE `ref_trans_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_user_type`
--
ALTER TABLE `ref_user_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles_menus`
--
ALTER TABLE `roles_menus`
 ADD PRIMARY KEY (`id`), ADD KEY `roles_id` (`roles_id`), ADD KEY `menus_id` (`menus_id`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
 ADD PRIMARY KEY (`id`), ADD KEY `account_id` (`account_id`), ADD KEY `q_id` (`q_id`), ADD KEY `a_id` (`a_id`), ADD KEY `trans_type` (`trans_type`), ADD KEY `trans_system` (`trans_system`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD KEY `user_type` (`user_type`);

--
-- Indexes for table `users_customer`
--
ALTER TABLE `users_customer`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `users_profi`
--
ALTER TABLE `users_profi`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `user_categories`
--
ALTER TABLE `user_categories`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `user_files`
--
ALTER TABLE `user_files`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `account_balance`
--
ALTER TABLE `account_balance`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `categories_prices`
--
ALTER TABLE `categories_prices`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `question_categories`
--
ALTER TABLE `question_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `question_price`
--
ALTER TABLE `question_price`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ref_roles`
--
ALTER TABLE `ref_roles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ref_trans_systems`
--
ALTER TABLE `ref_trans_systems`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ref_trans_type`
--
ALTER TABLE `ref_trans_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ref_user_type`
--
ALTER TABLE `ref_user_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `roles_menus`
--
ALTER TABLE `roles_menus`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=140;
--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=331;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `users_customer`
--
ALTER TABLE `users_customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `users_profi`
--
ALTER TABLE `users_profi`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user_categories`
--
ALTER TABLE `user_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_files`
--
ALTER TABLE `user_files`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
ADD CONSTRAINT `account_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `account_balance`
--
ALTER TABLE `account_balance`
ADD CONSTRAINT `account_balance_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`);

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`roles_id`) REFERENCES `ref_roles` (`id`);

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
ADD CONSTRAINT `answers_ibfk_3` FOREIGN KEY (`q_id`) REFERENCES `questions` (`id`),
ADD CONSTRAINT `answers_ibfk_4` FOREIGN KEY (`profi_id`) REFERENCES `users_profi` (`id`);

--
-- Constraints for table `categories_prices`
--
ALTER TABLE `categories_prices`
ADD CONSTRAINT `categories_prices_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users_customer` (`id`);

--
-- Constraints for table `question_categories`
--
ALTER TABLE `question_categories`
ADD CONSTRAINT `question_categories_ibfk_1` FOREIGN KEY (`q_id`) REFERENCES `questions` (`id`),
ADD CONSTRAINT `question_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `question_price`
--
ALTER TABLE `question_price`
ADD CONSTRAINT `question_price_ibfk_1` FOREIGN KEY (`q_id`) REFERENCES `questions` (`id`);

--
-- Constraints for table `roles_menus`
--
ALTER TABLE `roles_menus`
ADD CONSTRAINT `roles_menus_ibfk_1` FOREIGN KEY (`roles_id`) REFERENCES `ref_roles` (`id`),
ADD CONSTRAINT `roles_menus_ibfk_2` FOREIGN KEY (`menus_id`) REFERENCES `menus` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
ADD CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`trans_type`) REFERENCES `ref_trans_type` (`id`),
ADD CONSTRAINT `transactions_ibfk_5` FOREIGN KEY (`a_id`) REFERENCES `answers` (`id`),
ADD CONSTRAINT `transactions_ibfk_6` FOREIGN KEY (`q_id`) REFERENCES `questions` (`id`),
ADD CONSTRAINT `transactions_ibfk_7` FOREIGN KEY (`trans_system`) REFERENCES `ref_trans_systems` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`user_type`) REFERENCES `ref_user_type` (`id`);

--
-- Constraints for table `users_customer`
--
ALTER TABLE `users_customer`
ADD CONSTRAINT `users_customer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users_profi`
--
ALTER TABLE `users_profi`
ADD CONSTRAINT `users_profi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_categories`
--
ALTER TABLE `user_categories`
ADD CONSTRAINT `user_categories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
ADD CONSTRAINT `user_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `user_files`
--
ALTER TABLE `user_files`
ADD CONSTRAINT `user_files_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
